let gui;
let b;
let b1;
let b2;
let b3;


function setup() {
  createCanvas(400, 400);
  
  gui = createGui();
  b1 = createButton("Button",50, 10, 75, 75);
  b2 = createButton("Button",50, 110, 75, 75);
   b3 = createButton("Button",50, 210, 75, 75);
    b = createButton("Button",50, 310, 75, 75);
}

function draw() {
  background(220);
  drawGui();

  if(b.isPressed) {
     console.log("b is pressed!");
    fill(255,0,0);
  }

if(b1.isPressed) {
     console.log("b1 is pressed!");
    fill(0, 255, 0);
      
}
  if(b2.isPressed) {
     console.log("b2 is pressed!");
    fill(255, 255, 0)
}
   if(b3.isPressed) {
     console.log("b3 is pressed!");
    fill(0, 102, 255);
      
}
  ellipse(250, 200, 200);
  }
